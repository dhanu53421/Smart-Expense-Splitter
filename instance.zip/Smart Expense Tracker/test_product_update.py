#!/usr/bin/env python3

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from smart_expense_splitter import app, db
from models import User, Group, Member, Bill, Product, ProductMember

def test_product_update():
    """Test product update functionality"""
    
    with app.app_context():
        # Find existing product (ID 3 based on logs)
        product = Product.query.get(3)
        if not product:
            print("Product ID 3 not found")
            return False
            
        print(f"Original product: {product.name}, Price: ${product.price}")
        print(f"Original payer: {product.payer.name}")
        print(f"Original members involved: {[pm.member.name for pm in product.members_involved]}")
        
        # Test the update logic from the route
        try:
            # Simulate form data
            new_name = "Updated Product Name"
            new_price = 99.99
            new_payer_id = product.bill.group.members[0].id if product.bill.group.members else product.payer_id
            new_members_involved = [m.id for m in product.bill.group.members[:2]] if len(product.bill.group.members) >= 2 else [m.id for m in product.bill.group.members]
            
            # Apply the update logic from the route
            product.name = new_name
            product.price = new_price
            product.payer_id = new_payer_id
            
            # Remove existing product_member associations
            ProductMember.query.filter_by(product_id=product.id).delete()
            
            # Add new members involved
            for member_id in new_members_involved:
                product_member = ProductMember(
                    product_id=product.id,
                    member_id=member_id
                )
                db.session.add(product_member)
            
            # Commit the changes
            db.session.commit()
            
            print(f"Updated product: {product.name}, Price: ${product.price}")
            print(f"Updated payer: {product.payer.name}")
            print(f"Updated members involved: {[pm.member.name for pm in product.members_involved]}")
            print("✅ Product update test successful!")
            return True
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Product update test failed: {e}")
            return False

if __name__ == "__main__":
    success = test_product_update()
    sys.exit(0 if success else 1)