import sqlite3
import os

def check_and_fix_database(db_path, db_name=""):
    """Check database schema and add missing mobile_number column"""
    
    print(f"\n=== Checking {db_name} Database: {db_path} ===")
    
    if not os.path.exists(db_path):
        print(f"Database {db_path} not found!")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check current schema of members table
        cursor.execute("PRAGMA table_info(members)")
        columns = cursor.fetchall()
        print("Current members table schema:")
        for col in columns:
            print(f"  {col[1]}: {col[2]}")
        
        # Check if mobile_number column exists
        mobile_number_exists = any(col[1] == 'mobile_number' for col in columns)
        
        if not mobile_number_exists:
            print("\nmobile_number column not found. Adding it...")
            
            # Add mobile_number column
            cursor.execute("ALTER TABLE members ADD COLUMN mobile_number VARCHAR(20)")
            
            # Update existing records with default values
            cursor.execute("UPDATE members SET mobile_number = '0000000000'")
            
            conn.commit()
            print("Successfully added mobile_number column!")
            
            # Verify the change
            cursor.execute("PRAGMA table_info(members)")
            columns = cursor.fetchall()
            print("\nUpdated members table schema:")
            for col in columns:
                print(f"  {col[1]}: {col[2]}")
            
        else:
            print("\nmobile_number column already exists.")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"Error: {e}")
        return False

def check_all_databases():
    """Check both main and instance databases"""
    
    # Check main database
    main_db = "expense_splitter.db"
    main_success = check_and_fix_database(main_db, "MAIN")
    
    # Check instance database
    instance_db = "instance/expense_splitter.db"
    instance_success = check_and_fix_database(instance_db, "INSTANCE")
    
    return main_success and instance_success

if __name__ == "__main__":
    success = check_all_databases()
    if success:
        print("\n=== ALL DATABASE FIXES COMPLETED SUCCESSFULLY! ===")
    else:
        print("\n=== SOME DATABASE FIXES FAILED! ===")