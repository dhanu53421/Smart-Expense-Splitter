from smart_expense_splitter import app
from flask import url_for

# List of routes to test (replace IDs with valid ones for your DB)
routes = [
    '/',
    '/login',
    '/logout',
    '/register',
    '/dashboard',
    '/group/new',
    # Example IDs, replace with actual IDs from your DB
    '/group/1',
    '/group/1/edit',
    '/group/1/member/new',
    '/member/1/edit',
    '/group/1/bill/new',
    '/bill/1',
    '/bill/1/edit',
    '/bill/1/product/new',
    '/product/1/edit',
    '/bill/1/export/csv',
    '/bill/1/export/excel',
]

def test_routes():
    with app.test_client() as client:
        for route in routes:
            response = client.get(route)
            print(f"Testing {route}: Status {response.status_code}")
            if response.status_code >= 400:
                print(f"Error on {route}: {response.status}")

if __name__ == "__main__":
    test_routes()
