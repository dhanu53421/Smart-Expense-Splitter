import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    print("Testing Flask application startup...")
    
    # Test imports
    from flask import Flask
    from flask_sqlalchemy import SQLAlchemy
    from flask_login import LoginManager
    print("✓ All Flask imports successful")
    
    # Test database models
    from models import db, User, Group, Member, Bill, Product
    print("✓ All models imported successfully")
    
    # Create minimal app to test database
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'test-secret-key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///instance/expense_splitter.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    
    with app.app_context():
        print("Testing database connection...")
        
        # Test basic queries
        user_count = User.query.count()
        print(f"✓ Found {user_count} users in database")
        
        group_count = Group.query.count()
        print(f"✓ Found {group_count} groups in database")
        
        member_count = Member.query.count()
        print(f"✓ Found {member_count} members in database")
        
        # Test member query with mobile_number
        if member_count > 0:
            member = Member.query.first()
            print(f"✓ First member: {member.name}, mobile: {member.mobile_number}")
        
        print("\n✅ All database tests passed! The mobile_number issue is fixed.")
        
except Exception as e:
    print(f"\n❌ Error: {e}")
    import traceback
    traceback.print_exc()