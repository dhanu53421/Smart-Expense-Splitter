import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    # Test basic imports
    print("Testing imports...")
    from models import db, Member, Group
    print("✓ Models imported successfully")
    
    # Test database connection
    print("\nTesting database connection...")
    from smart_expense_splitter import app
    
    with app.app_context():
        # Test querying members
        print("Testing member queries...")
        members = Member.query.all()
        print(f"✓ Found {len(members)} members in database")
        
        # Test creating a test member
        print("\nTesting member creation...")
        test_group = Group.query.first()
        if test_group:
            print(f"✓ Found test group: {test_group.name}")
            
            # Test member with mobile_number
            test_member = Member(
                name="Test Member",
                email="test@example.com",
                mobile_number="1234567890",
                group_id=test_group.id
            )
            print("✓ Test member created successfully with mobile_number")
        else:
            print("⚠ No test groups found")
            
        print("\n✅ Database is working correctly!")
        
except Exception as e:
    print(f"\n❌ Error: {e}")
    import traceback
    traceback.print_exc()