import requests
import re

# Create a session to maintain cookies
session = requests.Session()

# First, get the login page to obtain CSRF token
login_page = session.get('http://127.0.0.1:5000/login')
print(f"Login page status: {login_page.status_code}")

# Try different CSRF token patterns
csrf_patterns = [
    r'name="csrf_token" value="([^"]+)"',
    r'csrf_token.*?value="([^"]+)"',
    r'value="([^"]+)".*?name="csrf_token"'
]

csrf_token = None
for pattern in csrf_patterns:
    csrf_match = re.search(pattern, login_page.text)
    if csrf_match:
        csrf_token = csrf_match.group(1)
        break

if csrf_token:
    print(f"Found CSRF token: {csrf_token}")
else:
    print("Could not find CSRF token in login page")
    print("Login page content preview:")
    print(login_page.text[:500])

# Try to access currency settings (this will redirect to login if not authenticated)
currency_page = session.get('http://127.0.0.1:5000/settings/currency')
print(f"\nCurrency page status: {currency_page.status_code}")
print(f"Currency page URL: {currency_page.url}")

if 'login' in currency_page.url.lower():
    print("Redirected to login page - need to authenticate")
    print("Login page content preview:")
    print(currency_page.text[:500])
else:
    print("Successfully accessed currency settings!")
    print("Checking for dropdown content...")
    
    # Look for select elements
    select_matches = re.findall(r'<select[^>]*>.*?</select>', currency_page.text, re.DOTALL)
    print(f"Found {len(select_matches)} select elements")
    
    # Look for option elements
    option_matches = re.findall(r'<option[^>]*>.*?</option>', currency_page.text)
    print(f"Found {len(option_matches)} option elements")
    
    # Look for USD specifically
    usd_matches = re.findall(r'USD', currency_page.text)
    print(f"Found {len(usd_matches)} USD references")
    
    # Save the full content for inspection
    with open('currency_authenticated.html', 'w', encoding='utf-8') as f:
        f.write(currency_page.text)
        print("Saved full currency page to currency_authenticated.html")